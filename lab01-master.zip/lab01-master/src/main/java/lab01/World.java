package lab01;

import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

public class World {
	
	public void draw(Canvas canvas) {
		GraphicsContext ctx = canvas.getGraphicsContext2D();
		ctx.setFill(Color.RED);
		ctx.fillRect(0, 0, canvas.getWidth(), canvas.getHeight());
	}
}
