package lab01;

import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

public class bullet {
	
	private double x;
	
	private double y;
	
	private double vx;
	
	private double vy;
	
	public bullet() {
		x=50;
		y=50;
	}
	
	public bullet(double ax, double ay, double speedax, double speeday) {
		x=ax;
		y=ay;
		vx= speedax;
		vy= speeday;
	}
	
	public void draw(Canvas canvas) {
		GraphicsContext ctx = canvas.getGraphicsContext2D();
		ctx.setFill(Color.SILVER);
		ctx.fillOval(x, y, 50, 50);
	}
	
	void uptdate(double deltat) {
		x=x+deltat*vx;
		y=y+deltat*vy;
	}
}
